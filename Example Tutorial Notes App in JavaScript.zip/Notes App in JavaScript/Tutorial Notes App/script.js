"use strict";

const btnAdd = document.querySelector('.btn-add');

const notes = JSON.parse(localStorage.getItem("notes"));

if (notes){
    notes.forEach((noteTxt) => addNote(noteTxt));
}

btnAdd.addEventListener('click', () => addNote());

function addNote(text = "") {
    const note = document.createElement("div");
    note.classList.add("note-wrapper");
    note.innerHTML = `<div class="operations">
        <button class="edit"><i class="bi bi-pencil-square"></i></button>
        <button class="delete"><i class="bi bi-trash-fill"></i></button>
      </div>

      <div class="main ${text ? "" : "hidden"}"></div>
      <textarea class="${text ? "hidden" : ""}"></textarea>`;
   
    const editBtn = note.querySelector(".edit");
    const deleteBtn = note.querySelector(".delete");
    const mainEL = note.querySelector(".main");
    const textAreaEL = note.querySelector("textarea");

    textAreaEL.value = text;
    mainEL.innerHTML = text;
    
    deleteBtn.addEventListener("click", () => {
        note.remove();
        updates();
    });

    editBtn.addEventListener("click", () => {
        mainEL.classList.toggle("hidden");
        text.classList.toggle("hidden");
    });

    textAreaEL.addEventListener("input", (e) => {
        const { value } = e.target;
        mainEL.innerHTML = value;
        updates();
    })

    document.body.appendChild(note);
}

function updates() {
    const noteText = document.querySelectorAll("textarea");
    const notes = [];

    noteText.forEach((note) => notes.push(note.value));
    localStorage.setItem("notes", JSON.stringify(notes));
}